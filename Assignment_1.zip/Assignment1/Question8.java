package Assignment1;

public class Question8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("***              ***     ***              ***     **     **");
		System.out.println("****            ****     ****            ****     **    **");
		System.out.println("** **          ** **     ** **          ** **     **   **");
		System.out.println("**  **        **  **     **  **        **  **     **  **");
		System.out.println("**   **      **   **     **   **      **   **     ****");
		System.out.println("**    **    **    **     **    **    **    **     **  **");
		System.out.println("**     **  **     **     **     **  **     **     **   **");
		System.out.println("**      ****      **     **      ****      **     **    **");
		System.out.println("**       **       **     **       **       **     **     **");
		
		
	}

}
