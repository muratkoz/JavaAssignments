package Assignment2;

public class Assignment2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Question 1
		int count=5197;
		System.out.println(count);
		
		//Question 2
		String message="Das ist ein Apfel";
		System.out.println(message);
	
		//Question 3
		int num=13;
		double cost=57.67;
		System.out.println(num + " " + cost);
		
		//Question 4
		String word="Entschuldigung";
		System.out.println("Today's Word-Of-The-Day is: " + word);
		
		//Question 5
		int first=100,second=200;
		System.out.println("first is "+first+" second = "+second);
		
		//Question 6
		String a1="James";
		String a2="Betty";
		String a3="Herb";
		String a4="Bob";
		String a5="Jill";
		System.out.println(a1+", "+a2+", "+a3+", "+a5+", "+a4);
		
		//Question 7
		int i=3330;
		float f=34.11f;
		System.out.println("i= " +i+" f= "+f);
		
		//Question 8
		String a11="Java";
		String a12="SQL";
		System.out.println("I will learn \"" +a11+ " and \"" +a12+ "\" at CybertekSchool");
		
		//Question 9
		byte steps=100;
		short miles=5000;
		int count1=1000000;
		long population=3434455667L;
		
		//Question 10
		int hour=17;
		int minute=25;
		int second1=13;
		String amOrPm= "PM";
		System.out.println(hour +":"+ minute +":"+ second1 +" "+amOrPm);
	
	
	
	}

}
