package assignment.day_2;

public class Question1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("I am ready to be a Java pro :)");
	}

}
