package assignment.day_2;

public class Question4 {

	public class Main {
	}
	public static void main(String[] arg) {
		System.out.println("Q");

	}
	}

	
