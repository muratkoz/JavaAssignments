package assignment.day_2;

public class Question6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println("    ^    ");
		System.out.println();
		System.out.println("   / \\  ");
		System.out.println("  /   \\ ");
		System.out.println(" /     \\");
		System.out.println(" |     |");		
		System.out.println(" |     |");
		System.out.println(" |     |");
		System.out.println(" |     |");
		System.out.println(" |     |");
		System.out.println(" |     |");
		System.out.println(" |     |");
		System.out.println(" _______");


	}

}
