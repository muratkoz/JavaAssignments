package assignment.day_2;

public class Question7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(" /\\  /\\");
		System.out.println("/__\\/__\\");
		System.out.println();
		System.out.println("I am from \"Germany\"\n");
		System.out.println("How is your day going on, \'good\' or \'bad\'?");
		
	}

}
